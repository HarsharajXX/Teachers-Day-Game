CSE TEACHERS' DAY LIVE HUNT 2026 - QR CODES BUNDLE
=====================================================
Target URL Base: https://ais-dev-6lajhjqfy7vryrbl5juvx6-563603576450.asia-southeast1.run.app

INSTRUCTIONS FOR ORGANIZERS:
1. Print these 20 QR codes on paper or sticker sheets.
2. Hide/place them around the CSE department labs, classrooms, and seminar spaces.
3. Students and attendees scan with any standard smartphone camera.
4. QRs #01 to #17 will reveal the real faculty tributes with photos, sound fanfare & confetti!
5. QRs #18, #19, and #20 are decoy markers ("Oops! Lost your chance").

QR CODES LIST:
[#01] TEACHER TRIBUTE: Dr. Uzzal Kr Sharma -> https://ais-dev-6lajhjqfy7vryrbl5juvx6-563603576450.asia-southeast1.run.app/?id=1
[#02] TEACHER TRIBUTE: Dr. Rubul Kumar Baniya -> https://ais-dev-6lajhjqfy7vryrbl5juvx6-563603576450.asia-southeast1.run.app/?id=2
[#03] TEACHER TRIBUTE: Dr. Pranjit Das -> https://ais-dev-6lajhjqfy7vryrbl5juvx6-563603576450.asia-southeast1.run.app/?id=3
[#04] TEACHER TRIBUTE: Dr. Diganta Pathak -> https://ais-dev-6lajhjqfy7vryrbl5juvx6-563603576450.asia-southeast1.run.app/?id=4
[#05] TEACHER TRIBUTE: Dr. Monalisa Hazarika -> https://ais-dev-6lajhjqfy7vryrbl5juvx6-563603576450.asia-southeast1.run.app/?id=5
[#06] TEACHER TRIBUTE: Sikha Moni -> https://ais-dev-6lajhjqfy7vryrbl5juvx6-563603576450.asia-southeast1.run.app/?id=6
[#07] TEACHER TRIBUTE: Prarthana Ma'am -> https://ais-dev-6lajhjqfy7vryrbl5juvx6-563603576450.asia-southeast1.run.app/?id=7
[#08] TEACHER TRIBUTE: Dr. Vivek Thapa -> https://ais-dev-6lajhjqfy7vryrbl5juvx6-563603576450.asia-southeast1.run.app/?id=8
[#09] TEACHER TRIBUTE: Ranjan Saikia -> https://ais-dev-6lajhjqfy7vryrbl5juvx6-563603576450.asia-southeast1.run.app/?id=9
[#10] TEACHER TRIBUTE: Dr. Bikramjit Sarma -> https://ais-dev-6lajhjqfy7vryrbl5juvx6-563603576450.asia-southeast1.run.app/?id=10
[#11] TEACHER TRIBUTE: Bishwajit Dev -> https://ais-dev-6lajhjqfy7vryrbl5juvx6-563603576450.asia-southeast1.run.app/?id=11
[#12] TEACHER TRIBUTE: Dr. Adil Akhtar -> https://ais-dev-6lajhjqfy7vryrbl5juvx6-563603576450.asia-southeast1.run.app/?id=12
[#13] TEACHER TRIBUTE: Bibha Ma'am -> https://ais-dev-6lajhjqfy7vryrbl5juvx6-563603576450.asia-southeast1.run.app/?id=13
[#14] TEACHER TRIBUTE: Liry Teronpi -> https://ais-dev-6lajhjqfy7vryrbl5juvx6-563603576450.asia-southeast1.run.app/?id=14
[#15] TEACHER TRIBUTE: Antariksha Baisa -> https://ais-dev-6lajhjqfy7vryrbl5juvx6-563603576450.asia-southeast1.run.app/?id=15
[#16] TEACHER TRIBUTE: Bedanta Nath -> https://ais-dev-6lajhjqfy7vryrbl5juvx6-563603576450.asia-southeast1.run.app/?id=16
[#17] TEACHER TRIBUTE: Himanshu Saikia -> https://ais-dev-6lajhjqfy7vryrbl5juvx6-563603576450.asia-southeast1.run.app/?id=17
[#18] DECOY MARKER: Decoy QR Marker A -> https://ais-dev-6lajhjqfy7vryrbl5juvx6-563603576450.asia-southeast1.run.app/?id=18
[#19] DECOY MARKER: Decoy QR Marker B -> https://ais-dev-6lajhjqfy7vryrbl5juvx6-563603576450.asia-southeast1.run.app/?id=19
[#20] DECOY MARKER: Decoy QR Marker C -> https://ais-dev-6lajhjqfy7vryrbl5juvx6-563603576450.asia-southeast1.run.app/?id=20
